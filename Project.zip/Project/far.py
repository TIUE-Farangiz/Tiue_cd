from email.mime import image
from tkinter import ttk
from tkinter import *
import tkinter as tk






class SampleApp(tk. Tk):
    def __init__(self,*arg,**kwargs):
        tk.Tk.__init__(self,*arg,**kwargs)
        container=tk.Frame(self)
        container.pack(side='top',fill='both',expand=True)
        container.grid_rowconfigure(0,weight=1)
        container.grid_columnconfigure(0,weight=1)

        self.frames={}
        for F in(StartPage, MenuPage,  Галерея, Выбрать, Контакты,Записаться, Master):
            page_name=F.__name__
            frame=F(parent=container,controller=self)
            self.frames[page_name]=frame

            frame.grid(row=0,column=0,sticky='nsew')

            self.show_frame('StartPage')

    def show_frame(self,page_name):
        frame = self.frames[page_name]
        frame.tkraise()

class StartPage(tk.Frame):
    def __init__(self,parent,controller):
        tk.Frame.__init__(self,parent)
        self.controller=controller
        self.controller.title('Beauty saloon')
        self.controller.geometry("1280x900")
        self.controller.resizable(0, 0)

        self.controller.iconbitmap()


        self.backGroundImage = PhotoImage(file = r'fon_1.png')
        self.backGroundImageLabel = Label(self, width=0, height=0,  image=self.backGroundImage)
        self.backGroundImageLabel.place(x = 0, y = 0)






        big_lable=tk.Label(self,text='Beauty saloon', font=('Goudy Stout',25,'bold'),fg='white',bg='#19c0be')
        big_lable.pack(pady=30)

        login_lable=tk.Label(self,text='Введите ваш логин', font=('Goudy Stout',15,'bold'), bg='#19c0be', fg='white')
        login_lable.pack(pady=30)

        my_login=tk.StringVar()
        login_entry=tk.Entry(self,textvariable=my_login, font=('Candara',15,'bold'), bg='white', fg='black')
        login_entry.pack(pady=30)

        password_lable=tk.Label(self,text='Введите свой пароль', font=('Goudy Stout',15,'bold'),bg='#19c0be',fg='white')
        password_lable.pack(pady=30)

        my_password= tk.StringVar()
        password_entry = tk.Entry(self, textvariable=my_password, font=('Candara', 15, 'bold'), bg='white',fg='black')
        password_entry.pack(pady=30)


        def check_password():
            if my_password.get()=='7788' and my_login.get()=='fali':
                controller.show_frame('MenuPage')



            else:
                right_lable['text']='Неверный пароль или логин'

        password_button=tk.Button(self,text='Войти',command=check_password,
                                  font=('Goudy Stout',10,'bold'),bg='#19c0be',fg='white')
        password_button.pack()
        right_lable=tk.Label(self,font=('Goudy Stout',10,'bold'), bg='#713267',fg='white')
        right_lable.pack(pady=30)

class MenuPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent,)
        self.controller=controller

        
        self.backGroundImage = PhotoImage(file = r'fon_2.png')
        self.backGroundImageLabel = Label(self, width=0, height=0,  image=self.backGroundImage)
        self.backGroundImageLabel.place(x = 0, y = 0)

        big_lable = tk.Label(self, text='Welcome to beauty saloon', font=('Candara', 50, 'bold'), fg='white', bg='#19c0be')
        big_lable.pack(pady=30)
        big_lable.place(x=200, y=40)

        def Master():
            controller.show_frame('Master')

        contact_button = tk.Button(self, text="Личный кабинет мастера", command=(Master), font=('Candara', 25, 'bold'),
                                   fg='white', bg='#19c0be')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=200)

        def Записаться():
            controller.show_frame('Записаться')

        contact_button = tk.Button(self, text="Записаться", command=(Записаться), font=('Candara', 25, 'bold'), fg='white',
                                   bg='#19c0be')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=300)

        def Галерея():
            controller.show_frame('Галерея')

        contact_button = tk.Button(self, text="Галерея", command=(Галерея), font=('Candara', 25, 'bold'), fg='white', bg='#19c0be')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=400)


        def Контакты():
            controller.show_frame('Контакты')

        contact_button = tk.Button(self, text="Контакты", command=(Контакты), font=('Candara', 25, 'bold'), fg='white', bg='#19c0be')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=500)






        def exit():
            controller.show_frame('StartPage')

        tab_button = tk.Button(self, text=" Back ", activebackground="white",  activeforeground="pink", command=exit, bg="#19c0be",  width = 20,  font=('Candara', 20, 'bold'),  fg="white")
        tab_button.pack()
        tab_button.place(x = 10, y=600)


class Master(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        self.backGroundImage = PhotoImage(file=r'fon_5.png')
        self.backGroundImageLabel = Label(self, width=0, height=0, image=self.backGroundImage)
        self.backGroundImageLabel.place(x=0, y=0)

        big_lable = tk.Label(self, text='Личный кабинет мастера', font=('Candara', 25, 'bold'), fg='black', bg='#19c0be')
        big_lable.place(x=10, y=10)

        def exit():
            controller.show_frame('MenuPage')

        tab_button = tk.Button(self, text=" назад ", activebackground="white",  activeforeground="pink", command=exit, bg="#19c0be",  width = 15,  font=('Candara', 15, 'bold'),  fg="black")
        tab_button.pack()
        tab_button.place(x = 10, y=300)


        def rec():
            controller.show_frame('rec')

        tab_button = tk.Label(self, text=" Записанные ",
                                bg="#19c0be",
                                width = 20,
                                font=('Candara', 20, 'bold'),
                                fg="black")
        tab_button.place(x = 10, y=60)

        def ИмяМастера():
                contact_lable = tk.Label(self, text="Login: _sveta_makeup \n Ваши данные \n tel.  99 000 00 00  \n ID  77777 \n ЛИ \n Светлана \n год рождения 2000",
                                                font=('Wide Latin', 15, 'bold'),
                                                bg='#19c0be',
                                                fg='black')
                contact_lable.place(x=650, y=200)

        contact_button = tk.Button(self, text='Имя Мастера', command=(ИмяМастера),
                                       font=('Bernard MT condensed', 15, 'bold'), bg='#19c0be', fg='black', width=15)
        contact_button.place(x=10, y=200)



        



class Галерея(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, )
        self.controller = controller

        self.backGroundImage = PhotoImage(file=r'fon_3.png')
        self.backGroundImageLabel = Label(self, width=0, height=0, image=self.backGroundImage)
        self.backGroundImageLabel.place(x=0, y=0)

        big_lable = tk.Label(self, text='Галерея', font=('Candara', 50, 'bold'), fg='black', bg='#19c0be')
        big_lable.pack(pady=30)

        def Выбрать():
            controller.show_frame('Выбрать')

        contact_button = tk.Button(self, text="Выбрать", command=(Выбрать), font=('Candara', 35, 'bold'), fg='black',
                                   bg='#19c0be')
        contact_button.pack(pady=30)
        contact_button.place(x=530, y=400)



        def return_MenuPage():
            controller.show_frame('MenuPage')

        return_button = tk.Button(self, text='Back', command=return_MenuPage,font=('Candara', 25, 'bold'), fg='black', bg='#19c0be')
        return_button.pack(pady=300)
        return_button.place(x=10, y=700)


class Выбрать(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, )
        self.controller = controller

        self.backGroundImage = PhotoImage(file=r'fon_4.png')
        self.backGroundImageLabel = Label(self, width=0, height=0, image=self.backGroundImage)
        self.backGroundImageLabel.place(x=0, y=0)

        big_lable = tk.Label(self, text='Галерея', font=('Candara', 50, 'bold'), fg='black', bg='#19c0be')
        big_lable.pack(pady=30)



        def ИмяМастера():
                contact_lable = tk.Label(self, text="Asal", font=('Wide Latin', 30, 'bold'),
                                                bg='#19c0be',
                                                fg='black')
                contact_lable.pack(pady=50)
                contact_lable.place(x=550, y=450)

        contact_button = tk.Button(self, text='ИмяМастера', command=(ИмяМастера),
                                       font=('Bernard MT condensed', 25, 'bold'), bg='#19c0be', fg='black', width=20)
        contact_button.pack(pady=50)
        contact_button.place(x=10, y=450)


        def Back():
            controller.show_frame('Галерея')

        return_button = tk.Button(self, text='Back', command=Back, font=('Candara', 25, 'bold'), fg='black',
                                  bg='#19c0be')
        return_button.pack(pady=300)
        return_button.place(x=10, y=700)


class Контакты(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, )
        self.controller = controller

        self.backGroundImage = PhotoImage(file=r'fon_1.png')
        self.backGroundImageLabel = Label(self, width=0, height=0, image=self.backGroundImage)
        self.backGroundImageLabel.place(x=0, y=0)

        big_lable = tk.Label(self, text='Best of the best Salon' , font=('Candara', 50, 'bold'), fg='black', bg='#19c0be')
        big_lable.pack(pady=30)

        def Контакты():
                contact_lable = tk.Label(self, text="+99897777-77-77", font=('Wide Latin', 30, 'bold'),
                                                bg='#19c0be',
                                                fg='black')
                contact_lable.pack(pady=50)
                contact_lable.place(x=550, y=300)

        contact_button = tk.Button(self, text='Контакты', command=(Контакты),
                                       font=('Bernard MT condensed', 25, 'bold'), bg='#19c0be', fg='black', width=20)
        contact_button.pack(pady=50)
        contact_button.place(x=10, y=300)

        def Loc():
                contact_lable = tk.Label(self, text="Nest One, ~Tashkenk City~", font=('Wide Latin', 25, 'bold'),
                                                bg='#19c0be',
                                                fg='black')
                contact_lable.pack(pady=50)
                contact_lable.place(x=450, y=400)

        contact_button = tk.Button(self, text='Location', command=(Loc),
                                       font=('Bernard MT condensed', 25, 'bold'), bg='#19c0be', fg='black', width=20)
        contact_button.pack(pady=50)
        contact_button.place(x=10, y=400)






        def return_MenuPage():
            controller.show_frame('MenuPage')

        return_button = tk.Button(self, text='Back', command=return_MenuPage,font=('Candara', 25, 'bold'), fg='black', bg='#19c0be')
        return_button.pack(pady=300)
        return_button.place(x=10, y=700)

class Записаться(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, )
        self.controller = controller

        self.backGroundImage = PhotoImage(file=r'fon_4.png')
        self.backGroundImageLabel = Label(self, width=0, height=0, image=self.backGroundImage)
        self.backGroundImageLabel.place(x=0, y=0)

        big_lable = tk.Label(self, text='Записаться', font=('Candara', 50, 'bold'), fg='black', bg='#19c0be')
        big_lable.pack(pady=30)

        def Услуги():
            result_contact_lable = tk.Checkbutton(self,  text="MakeUp",
                                                  font=('Wide Latin', 15, 'bold'), bg='#19c0be',
                                                  fg='black')
            result_contact_lable.pack(pady=50)
            result_contact_lable.place(x=400, y=470)
            result_contact_lable = tk.Checkbutton(self,  text=" Face care",
                                                  font=('Wide Latin', 15, 'bold'), bg='#19c0be',
                                                  fg='black')
            result_contact_lable.pack(pady=50)
            result_contact_lable.place(x=680, y=470)
            result_contact_lable = tk.Checkbutton(self,
                                                  text="Beauty hair", font=('Wide Latin', 15, 'bold'), bg='#19c0be',
                                                  fg='black')
            result_contact_lable.pack(pady=50)
            result_contact_lable.place(x=980, y=470)

        contact_button = tk.Button(self, text='Услуги', command=(Услуги),
                                   font=('Bernard MT condensed', 25, 'bold'), bg='#19c0be', fg='black', width=20)
        contact_button.pack(pady=25)
        contact_button.place(x=10, y=450)

        def return_MenuPage():
            controller.show_frame('MenuPage')

        return_button = tk.Button(self, text='Back', command=return_MenuPage,font=('Candara', 25, 'bold'), fg='black', bg='#19c0be')
        return_button.pack(pady=300)
        return_button.place(x=10, y=700)








if __name__=='__main__':
    app = SampleApp()
    app.mainloop()

